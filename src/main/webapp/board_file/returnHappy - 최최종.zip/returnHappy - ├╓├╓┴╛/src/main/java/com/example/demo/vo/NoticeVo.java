package com.example.demo.vo;

import lombok.Data;

@Data
public class NoticeVo
{
	private int notice_num;
	private String notice_title;
	private String notice_content;
	private String notice_date;
	private int notice_count;

}
