package com.example.demo.vo;

import lombok.Data;

@Data
public class PaymentVo
{

}
