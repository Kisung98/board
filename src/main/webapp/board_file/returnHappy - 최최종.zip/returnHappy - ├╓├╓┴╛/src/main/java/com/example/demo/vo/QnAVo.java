package com.example.demo.vo;

import lombok.Data;

@Data
public class QnAVo
{
	private int qna_num;
	private String qna_title;
	private String qna_content;
	private String qna_date;
}
