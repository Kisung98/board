package com.example.demo.vo;

import lombok.Data;

@Data
public class QnA_ReplyVo
{
	private int reply_num;
	private String reply_content;
	private String reply_date;
}
